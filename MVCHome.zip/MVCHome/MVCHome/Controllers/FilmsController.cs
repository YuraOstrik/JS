﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using MVCHome.Models;
namespace MVCHome.Controllers
{
    public class FilmsController : Controller
    {
        FilmsContext db;
        public FilmsController(FilmsContext context)
        {
            db = context;
        }

        public async Task<IActionResult> Index()
        {
            return View(await db.Films.ToListAsync());
        }

        public async Task<IActionResult> Details(int? id)
        {
            if (id == null) {
                return NotFound();
            }
            var film = await db.Films.FirstOrDefaultAsync(m => m.id == id);
            if(film == null)
            {
                return NotFound();
            }
            return View(film);
        }

        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("id,Name,Director,Genre,Year,Poster,Description")] Films film)
        {
            if (ModelState.IsValid)
            {
                db.Add(film);
                await db.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(film);
        }

        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var film = await db.Films.FindAsync(id);
            if (film == null)
            {
                return NotFound();
            }
            return View(film);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("id,Name,Director,Genre,Year,Poster,Description")] Films film)
        {
            if (id != film.id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    db.Update(film);
                    await db.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!FilmExists(film.id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(film);
        }

        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var film = await db.Films.FirstOrDefaultAsync(m => m.id == id);
            if (film == null)
            {
                return NotFound();
            }
            return View(film);
        }

        // POST: Students/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var film = await db.Films.FindAsync(id);
            if (film != null)
            {
                db.Films.Remove(film);
            }

            await db.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }



        private bool FilmExists(int id)
        {
            return db.Films.Any(e => e.id == id);
        }

    }
}
