﻿using Microsoft.AspNetCore.Mvc.Filters;
using System.Globalization;

// Фильтры действий (Action Filters) реализуют либо интерфейс IActionFilter, либо интерфейс IAsyncActionFilter. Фильтры действий выполняются после фильтров авторизации и ресурсов и уже после того, как произошла привязка модели.

namespace MVCBook.Filters
{
    // модификаторы доступа для каждого файла ресурсов установлены в public. 
    // У файлов ресурсов значение свойства «Custom Tool» равно «PublicResXFileCodeGenerator» - инструмент создания ресурсов.
    // Иначе файлы ресурсов не будут скомпилированы и доступны.
    // Build Action - Embedded Resource
    // Custom Tool Namespace - Resources.


    public class CultureAttribute : Attribute, IActionFilter
    {

        public void OnActionExecuted(ActionExecutedContext filterContext)
        {

        }

        // фильтр действий, который будет срабатывать при обращении к действиям контроллера и производить локализацию.
        public void OnActionExecuting(ActionExecutingContext filterContext)
        {
            // Список поддерживаемых культур
            List<string> cultures = new List<string>() { "en", "uk", "fr" };

            // Получаем язык из куки
            string? cultureName = filterContext.HttpContext.Request.Cookies["lang"];

            // Если куки нет или язык не поддерживается, ставим язык по умолчанию
            if (string.IsNullOrEmpty(cultureName) || !cultures.Contains(cultureName))
            {
                cultureName = "en";
            }

            // Создаём объект CultureInfo
            var cultureInfo = CultureInfo.CreateSpecificCulture(cultureName);

            // Устанавливаем для текущего потока
            Thread.CurrentThread.CurrentCulture = cultureInfo;
            Thread.CurrentThread.CurrentUICulture = cultureInfo;

            // Теперь Razor будет брать нужный ресурс
        }

    }
}