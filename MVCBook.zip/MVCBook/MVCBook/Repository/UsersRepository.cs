﻿using Microsoft.AspNetCore.Mvc;
using MVCBook.Models;

namespace MVCBook.Repository
{
    public class UsersRepository : IRepository
    {
        private readonly UsersContext _context;
        public UsersRepository(UsersContext context) { _context = context; }

        public IQueryable<Users> Users => _context.Users;
        public IQueryable<Messages> Messages => _context.Messages;

        public void AddUser(Users user) => _context.Users.Add(user);
        public void AddMessage(Messages message) => _context.Messages.Add(message);

        public async Task SaveAsync() => await _context.SaveChangesAsync();
    }
}
