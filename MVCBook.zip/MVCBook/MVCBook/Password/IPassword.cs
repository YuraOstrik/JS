﻿namespace MVCBook.Password
{
    public interface IPassword
    {
        string GenerateSalt(int size = 16);
        string HashPassword(string password, string salt);
    }
}
