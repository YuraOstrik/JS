using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using MVCBook.Models;
using System.Data;
using System.Diagnostics;
using System.Threading.Tasks;

namespace MVCBook.Controllers
{
    public class HomeController : Controller
    {
        public readonly UsersContext db; 
        public HomeController(UsersContext context)
        {
            db = context;
        }
        public ActionResult Logout()
        {
            HttpContext.Session.Clear();
            return RedirectToAction("");
        }
        public ActionResult Index()
        {
            if (HttpContext.Session.GetString("FullName") != null)
                return View();
            else
                return RedirectToAction("Login", "Account");
        }

        public ActionResult SendMessage()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> SendMessage(Messages message)
        {
            if (ModelState.IsValid)
            {
                if(message.Text == null)
                {
                    ModelState.AddModelError("", "Enter your message");
                }
                var userName = HttpContext.Session.GetString("FullName");
                var user = db.Users.FirstOrDefault(u => u.FullName == userName);

                if (user != null)
                {
                    message.User = user;                
                    message.MessagesDate = DateTime.Now; 

                    db.Messages.Add(message);           
                    await db.SaveChangesAsync();        
                }
            }
            return RedirectToAction("Index");
        }

        public IActionResult Table()
        {
            if (HttpContext.Session.GetString("FullName") != null)
            {
                var messages = db.Messages
                 .Include(m => m.User)
                 .Where(m => m.User != null)   
                 .OrderByDescending(m => m.MessagesDate)
                 .ToList();
                return View(messages);
            }
            else
            {
                return RedirectToAction("Index");
            }
        }

    }
}
