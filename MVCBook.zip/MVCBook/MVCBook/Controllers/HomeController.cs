using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using MVCBook.Models;
using MVCBook.Repository;
using System.Data;
using System.Diagnostics;
using System.Threading.Tasks;

namespace MVCBook.Controllers
{
    public class HomeController : Controller
    {
        private readonly IRepository _repository;

        public HomeController(IRepository repository)
        {
            _repository = repository;
        }

        public IActionResult Logout()
        {
            HttpContext.Session.Clear();
            return RedirectToAction("");
        }

        public IActionResult Index()
        {
            if (HttpContext.Session.GetString("FullName") != null)
                return View();
            else
                return RedirectToAction("Login", "Account");
        }

        public IActionResult SendMessage() => View();

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> SendMessage(Messages message)
        {
            if (!ModelState.IsValid || string.IsNullOrWhiteSpace(message.Text))
            {
                ModelState.AddModelError("", "Enter your message");
                return View(message);
            }

            var userName = HttpContext.Session.GetString("FullName");
            var user = _repository.Users.FirstOrDefault(u => u.FullName == userName);

            if (user != null)
            {
                message.User = user;
                message.MessagesDate = DateTime.Now;

                _repository.AddMessage(message);
                await _repository.SaveAsync();
            }

            return RedirectToAction("Index");
        }

        public IActionResult Table()
        {
            if (HttpContext.Session.GetString("FullName") == null)
                return RedirectToAction("Index");

            var messages = _repository.Messages
                .Include(m => m.User)
                .Where(m => m.User != null)
                .OrderByDescending(m => m.MessagesDate)
                .ToList();

            return View(messages);
        }

        public IActionResult ChangeCulture(string lang, string? returnUrl)
        {
            var cultures = new List<string> { "en", "uk", "fr" };
            if (!cultures.Contains(lang))
                lang = "en";

            Response.Cookies.Append("lang", lang, new CookieOptions
            {
                Expires = DateTimeOffset.Now.AddDays(10)
            });

            return LocalRedirect(returnUrl ?? "/Home/Index");
        }
    }

}
